<?php

//JUST REDIRECT TO PAGES
header("location:index.php");

?>